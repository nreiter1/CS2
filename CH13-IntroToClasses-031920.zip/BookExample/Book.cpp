#include "Book.h"

//**********************************************
//Constructors/Deconstructors
//**********************************************
#pragma region constructors

//Default constructor, called when no other constructor is invokde
//Book book1;
Book::Book()
{
	//empty constructor
}

//ISBN Constructor, one string parameters, sets ISBN, all others left at default
//Book book1("99999");
Book::Book(string isbn)
{
	_ISBN = isbn;
}

//ISBN/Title Constructor, two strings, sets ISBN and Title of newly constructed book
//Book book1("99999","title of book");
Book::Book(string isbn, string title)
{
	_ISBN = isbn;
	_Title = title;
}

//COPY Constructor, copies existing book into instance of newly contructed book
//Book book2(book1)
//book2 is new book, book1 is existing book
Book::Book(const Book& other)
{
	 _ISBN = other._ISBN;
	 _Title = other._Title;
	 _Author = other._Author;
	 _Publisher = other._Publisher;
	 _Year = other._Year;
	_checkedIn = other._checkedIn;
}

//Deconstructor
Book::~Book()
{
	cout << "Deconstructing Book Object " << this->getISBN() << endl;
}

#pragma endregion constructors

//**********************************************
//Overloaded Operators
//**********************************************
#pragma region operators

//Overloads the = opertor
//book1 = book2;
Book Book::operator = (const Book& other)
{
	_ISBN = other._ISBN;
	_Title = other._Title;
	_Author = other._Author;
	_Publisher = other._Publisher;
	_Year = other._Year;
	_checkedIn = other._checkedIn;
	return *this;
}

//Overloads the == operator
//if(book1 == book2)
//Only criteria is that ISBNs match, could add others
bool Book::operator == (const Book& other)
{
	if (_ISBN == other._ISBN)
		return true;
	else
		return false;
}

//Overloads the << operator
//cout << book1;
//Displays all fields of the book
ostream& operator << (ostream& strm, const Book& book)
{
	strm << "ISBN:      " << book._ISBN << endl;
	strm << "Title:     " << book._Title << endl;
	strm << "Author:    " << book._Author << endl;
	strm << "Publisher: " << book._Publisher << endl;
	strm << "Year:      " << book._Year << endl;
	if (book._checkedIn)
		strm << "Checked In" << endl;
	else
		strm << "Checked Out" << endl;
	return strm;
}

//Overloads the >> operator
//cin >> book1;
//Gets data from the user and stores it in the fields of the book object
istream& operator >> (istream& strm, Book& book)
{
	cout << "ISBN:      ";
	strm >> book._ISBN;
	cout << "Title:     ";
	strm >> book._Title;
	cout << "Author:    ";
	strm >> book._Author;
	cout << "Publisher: ";
	strm >> book._Publisher;
	cout << "Year:      ";
	strm >> book._Year;
	book._checkedIn = true;
	return strm;
}
#pragma endregion operators

//**********************************************
//Getters/Setters Accessors/Mutators
//**********************************************
#pragma region getset
void Book::setISBN(string isbn)
{
	_ISBN = isbn;
}

string Book::getISBN()
{
	return _ISBN;
}

void Book::setTitle(string title)
{
	_Title = title;
}

string Book::getTitle()
{
	return _Title;
}

void Book::setAuthor(string author)
{
	_Author = author;
}

string Book::getAuthor()
{
	return _Author;
}
void Book::setPublisher(string publisher)
{
	_Publisher = publisher;
}

string Book::getPublisher()
{
	return _Publisher;
}

void Book::setYear(string year)
{
	_Year = year;
}

string Book::getYear()
{
	return _Year;
}

void Book::checkIn()
{
	_checkedIn = true;
}

void Book::checkOut()
{
	_checkedIn = false;
}

bool Book::getStatus()
{
	return _checkedIn;
}
#pragma endregion getset