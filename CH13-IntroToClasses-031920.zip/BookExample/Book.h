#pragma once
#include <string>
#include <iostream>
using namespace std;

class Book
{
private:
	string _ISBN;
	string _Title;
	string _Author;
	string _Publisher;
	string _Year;
	bool _checkedIn = false;

public:
	Book();
	Book(string);
	Book(string, string);
	Book(const Book&);
	~Book();

	Book operator = (const Book&);
	bool operator == (const Book&);
	friend ostream& operator << (ostream&, const Book&);
	friend istream& operator >> (istream& , Book&);

	void setISBN(string);
	string getISBN();
	void setTitle(string);
	string getTitle();
	void setAuthor(string);
	string getAuthor();
	void setPublisher(string);
	string getPublisher();
	void setYear(string);
	string getYear();

	void checkIn();
	void checkOut();
	bool getStatus();
};

