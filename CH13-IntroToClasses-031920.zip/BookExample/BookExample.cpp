
#include <iostream>
#include <vector>
#include "Book.h"
using namespace std;

int main()
{
	Book book1;
	Book book2;

	Book book3("9999", "Harry Potter");
	book3.setYear("2000");

	cin >> book1;
	cout << book1;


	//Create Library of multiple books
	vector<Book> library;
	//library.push_back(book1);


}

