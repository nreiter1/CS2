#include "Media.h"

void Media::setTitle(string title)
{
	_Title = title;
}
string Media::getTitle()
{
	return _Title;
}

void Media::setPublisher(string publisher)
{
	_Publisher = publisher;
}
string Media::getPublisher()
{
	return _Publisher;
}

void Media::setCost(float cost)
{
	_Cost = cost;
}
float Media::getCost()
{
	return _Cost;
}

void Media::checkIn()
{
	_checkedIn = true;
}

void Media::checkOut(int days)
{
	//depends on #include time.h
	struct tm newtime;
	__time64_t long_time;
	char timebuf[26];

	_time64(&long_time);						//get current system time
	_localtime64_s(&newtime, &long_time);		//localize the time

	_checkedOutDate = newtime;					//Today
	asctime_s(timebuf, 26, &newtime);			//Convert time to ascii
	cout << endl << "***** BOOK CHECKOUT **** " << endl;
	cout << "Today: " << timebuf << endl;

	newtime.tm_mday = newtime.tm_mday + days;		//add 'days' to current date
	_dueDate = newtime;							//'days' from now
	mktime(&newtime);
	asctime_s(timebuf, 26, &newtime);
	cout << "Due Date: " << timebuf << endl;
}
