#pragma once
#include <string>
#include <time.h>
#include <iostream>
using namespace std;

class Media
{

protected:
	string _Title;
	string _Publisher;
	float _Cost;
	bool _checkedIn;
	tm _checkedOutDate;
	tm _dueDate;

public:

	Media operator = (const Media&);

	void setTitle(string);
	string getTitle();

	void setPublisher(string);
	string getPublisher();

	void setCost(float);
	float getCost();

	void checkIn();
	void checkOut(int);
};

