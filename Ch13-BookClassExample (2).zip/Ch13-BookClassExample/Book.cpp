#include "Book.h"

//Constructors
Book::Book()
{
	//empty constructor
}

Book::Book(string title, string publisher, string author, string year, string isbn)
{
	_Title = title;
	_Publisher = publisher;
	_Author = author;
	_Year = year;
	_ISBN = isbn;
}

Book::~Book()
{
	
}

Book::Book(const Book& other)
{
	_ISBN = other._ISBN;
	_Title = other._Title;
	_Author = other._Author;
	_Publisher = other._Publisher;
	_Year = other._Year;
	_checkedIn = other._checkedIn;
}

//Overloades Operators
//Overloads the = opertor
//book1 = book2;
Book Book::operator = (const Book& other)
{
	_ISBN = other._ISBN;
	_Title = other._Title;
	_Author = other._Author;
	_Publisher = other._Publisher;
	_Year = other._Year;
	_checkedIn = other._checkedIn;
	return *this;
}

//Overloads the == operator
//if(book1 == book2)
//Only criteria is that ISBNs match, could add others
bool Book::operator == (const Book& other)
{
	if (_ISBN == other._ISBN)
		return true;
	else
		return false;
}

//Overloads the << operator
//cout << book1;
//Displays all fields of the book
ostream& operator << (ostream& strm, const Book& book)
{
	strm << "ISBN:      " << book._ISBN << endl;
	strm << "Title:     " << book._Title << endl;
	strm << "Author:    " << book._Author << endl;
	strm << "Publisher: " << book._Publisher << endl;
	strm << "Year:      " << book._Year << endl;
	if (book._checkedIn)
		strm << "Checked In" << endl;
	else
		strm << "Checked Out" << endl;
	return strm;
}

//Overloads the >> operator
//cin >> book1;
//Gets data from the user and stores it in the fields of the book object
istream& operator >> (istream& strm, Book& book)
{
	cout << "ISBN:      ";
	strm >> book._ISBN;
	cout << "Title:     ";
	strm >> book._Title;
	cout << "Author:    ";
	strm >> book._Author;
	cout << "Publisher: ";
	strm >> book._Publisher;
	cout << "Year:      ";
	strm >> book._Year;
	book._checkedIn = true;
	return strm;
}

//Accessors
void Book::setISBN(string isbn)
{
	_ISBN = isbn;
}

string Book::getISBN()
{
	return _ISBN;
}

void Book::setAuthor(string author)
{
	_Author = author;
}

string Book::getAuthor()
{
	return _Author;
}

void Book::setYear(string year)
{
	_Year = year;
}

string Book::getYear()
{
	return _Year;
}
