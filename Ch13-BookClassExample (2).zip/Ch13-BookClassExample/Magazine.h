#pragma once
#include "Media.h"
#include <string>
#include <iostream>
using namespace std;

class Magazine : public Media
{
private:
	string _MonthYear;  //Magazines are typically published each month, use string like 0420 to indicate April 2020
	string _Editor;
	int _Pages = 0;

public:
	Magazine();
	Magazine(string, string, string, string, int);

	Magazine(const Magazine&);
	~Magazine();

	Magazine operator = (const Magazine&);
	bool operator == (const Magazine&);
	friend ostream& operator << (ostream&, const Magazine&);
	friend istream& operator >> (istream&, Magazine&);

	void setMonthYear(string);
	string getMoneYear();

	void setEditor(string);
	string getEditor();

	void setPages(int);
	int getPages();
};

