#include "Magazine.h"

//Constructors
Magazine::Magazine()
{
	//empty constructor
}

Magazine::Magazine(string title, string publisher, string monthYear, string editor, int pages)
{
	_Title = title;
	_Publisher = publisher;
	_MonthYear = monthYear;
	_Editor = editor;
	_Pages = pages;
}

Magazine::Magazine(const Magazine& other)
{
	_Title = other._Title;
	_Publisher = other._Publisher;
	_MonthYear = other._MonthYear;
	_Editor = other._MonthYear;
	_Pages = other._Pages;
	_checkedIn = other._checkedIn;
}

Magazine::~Magazine()
{
	//default constructor
}

//Overloaded Operators
//Overloads the = opertor
//mag01 = mag01;
Magazine Magazine::operator = (const Magazine& other)
{
	_Title = other._Title;
	_Publisher = other._Publisher;
	_MonthYear = other._MonthYear;
	_Editor = other._Editor;
	_Pages = other._Pages;
	return *this;
}

//Overloads the == operator
//if(mag01 == mag02)
// criteria is that Title and MonthYear match
bool Magazine::operator == (const Magazine& other)
{
	if (_Title == other._Title && _MonthYear == other._MonthYear)
		return true;
	else
		return false;
}

//Overloads the << operator
//cout << mag01;
//Displays all fields of the magazine
ostream& operator << (ostream& strm, const Magazine& mag)
{
	strm << "Title:     " << mag._Title << endl;
	strm << "Publisher: " << mag._Publisher << endl;
	strm << "Month/Year:" << mag._MonthYear << endl;
	strm << "Editor:    " << mag._Editor << endl;
	strm << "Pages:     " << mag._Pages << endl;
		if (mag._checkedIn)
		strm << "Checked In" << endl;
	else
		strm << "Checked Out" << endl;
	return strm;
}

//Overloads the >> operator
//cin >> mag01;
//Gets data from the user and stores it in the fields of the magazine object
istream& operator >> (istream& strm, Magazine& mag)
{
	std::cout << "Title:     ";
	strm >> mag._Title;
	cout << "Publisher: ";
	strm >> mag._Publisher;
	cout << "MonthYear:   ";
	strm >> mag._MonthYear;
	cout << "Editor:      ";
	strm >> mag._Editor;
	cout << "Pages:       ";
	strm >> mag._Pages; 
	mag._checkedIn = true;
	return strm;
}

//Accessors
void Magazine::setMonthYear(string monthYear)
{
	_MonthYear = monthYear;
}

string Magazine::getMoneYear()
{
	return _MonthYear;
}

void Magazine::setEditor(string editor)
{
	_Editor = editor;
}

string Magazine::getEditor()
{
	return _Editor;
}

void Magazine::setPages(int pages)
{
	_Pages = pages;
}

int Magazine::getPages()
{
	return _Pages;
}
