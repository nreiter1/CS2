#pragma once
int const ROWS = 100;
int const COLS = 3;

int const FNAME = 0;
int const LNAME = 1;
int const JNUM = 2;
