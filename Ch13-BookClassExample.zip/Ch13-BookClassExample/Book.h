#pragma once
#include "Media.h"
#include <string>
#include <iostream>
using namespace std;

class Book : public Media
{
private:
	string _ISBN;
	string _Author;
	string _Year;

public:
	Book();
	Book(string, string, string, string, string);

	Book(const Book&);
	~Book();

	Book operator = (const Book&);
	bool operator == (const Book&);
	friend ostream& operator << (ostream&, const Book&);
	friend istream& operator >> (istream&, Book&);

	void setISBN(string);
	string getISBN();

	void setAuthor(string);
	string getAuthor();

	void setYear(string);
	string getYear();

};

