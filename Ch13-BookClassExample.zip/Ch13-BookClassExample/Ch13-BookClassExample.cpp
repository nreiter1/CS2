#include <vector>
#include "Book.h"
#include "Magazine.h"

int main()
{
    //************************
    //EXERCISE THE BOOK CLASS
    //************************
    Book book1;     //create a new empty book
    book1.setTitle("Harry the Dog");
    book1.setISBN("123456789");
    book1.checkIn();

    //Instantiate book, set Title, Publisher, Author, Year, ISBN
    Book book2("1111", "2222", "3333", "4444", "5555");

    vector<Book> BookLib;       //Create a book library...vector
    BookLib.push_back(book1);   //Add book to library
    BookLib.push_back(book2);   //Add book to library

    cout << "Enter data for book: " << endl;
    Book book3;
    cin >> book3;       //enter data in a new book, using overloades >> operator

    Book book4;
    book4 = book3;      //set book 4 to same values as book3 using overloaded operator '='

    if (book3 == book4) //test if book3 is equal to book4
        cout << "Books are the same" << endl;
    else
        cout << "Books are not the same " << endl;

    cout << book3;          //display fields of book using over loaded operator <<

    book1.checkOut(14);     //Check the book out from the library by setting its checkedIn flag and dates

    //************************
    //Exception Handling Example, see setCost function in Media.cpp
    //************************
    float cost;
    bool tryAgain = true;

    while (tryAgain)
    {
      cout << "Enter book cost: ";
      cin >> cost;

      try
        {
            book3.setCost(cost);
            tryAgain = false;
        }
      catch (string e)
        {
            cout << e;
        }
    }

    //************************
    //EXERCISE THE MAGAZINE CLASS
    //************************

    //Instantiate magazine
    Magazine mag01("66666", "77777", "88888", "99999", 200);

    //Add magazine to a magazine library
    vector<Magazine> MagLib;
    MagLib.push_back(mag01);


}

