#include "Media.h"

Media::Media() {}
Media::Media(string title, string publisher)
{
	_Title = title;
	_Publisher = publisher;
}


void Media::setTitle(string title)
{
	_Title = title;
}
string Media::getTitle()
{
	return _Title;
}

void Media::setPublisher(string publisher)
{
	_Publisher = publisher;
}
string Media::getPublisher()
{
	return _Publisher;
}

void Media::setCost(float cost)
{
	if (cost <= 0)
	{
		//must define string before throwing it
		//if you do it this way: throw ("Test Text");   it creates a char[], which must be caught as a char[]   
		string excep = "Please enter a number greater than ZERO (setCost)\n\n";
		throw excep;		//must be caught to have any effective use
	}
	else
		_Cost = cost;
}
float Media::getCost()
{
	return _Cost;
}

void Media::checkIn()
{
	_checkedIn = true;
}

void Media::checkOut(int days)
{
	//depends on #include time.h
	//Calculates and set _checkedOutDate to current time/date
	//Adds 'days' to the current time
	//Sets _dueDate to calculated time (time + days)
	struct tm newtime;
	__time64_t long_time;
	char timebuf[26];

	_time64(&long_time);						//get current system time
	_localtime64_s(&newtime, &long_time);		//localize the time

	_checkedOutDate = newtime;					//Today
	asctime_s(timebuf, 26, &newtime);			//Convert time to ascii
	cout << endl << "***** BOOK CHECKOUT **** " << endl;
	cout << "Today: " << timebuf << endl;

	newtime.tm_mday = newtime.tm_mday + days;		//add 'days' to current date
	_dueDate = newtime;							//'days' from now
	mktime(&newtime);
	asctime_s(timebuf, 26, &newtime);
	cout << "Due Date: " << timebuf << endl;
}
